from setuptools import setup

setup(name='distributions-mariofaragalla',
      version='0.2',
      description='Gaussian and Binomial distributions',
      packages=['distributions-mariofaragalla'],
      zip_safe=False)
